const form = document.getElementById("newsletter-form");
const emailInput = document.getElementById("email");

const container = document.querySelector(".container");
const successCard = document.querySelector(".success-card");

const userEmail = document.getElementById("user-email");
const dismissBtn = document.getElementById("dismiss-btn");

form.addEventListener("submit", function(e){

    e.preventDefault();

    const email = emailInput.value;

    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(emailPattern.test(email)){

        userEmail.textContent = email;

        container.style.display = "none";

        successCard.style.display = "block";

    }else{

        alert("Please enter a valid email address");

    }

});

dismissBtn.addEventListener("click", function(){

    successCard.style.display = "none";

    container.style.display = "flex";

    emailInput.value = "";

});